from setuptools import setup, find_packages

setup(name='testomundo',
      version='0.1',
      packages=find_packages())
