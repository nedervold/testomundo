def testing():
    print "testing",
    for x in [1,2,3]:
        print "%d," % x,
    print "..."
